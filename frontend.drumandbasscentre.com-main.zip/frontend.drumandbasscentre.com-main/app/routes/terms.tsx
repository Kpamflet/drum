import { Box } from '@mantine/core';
import React from 'react'

const TermsPage = () => {
    return (
        <Box mih="80vh">
            <div>AboutUs</div>
        </Box>
    )
}

export default TermsPage;