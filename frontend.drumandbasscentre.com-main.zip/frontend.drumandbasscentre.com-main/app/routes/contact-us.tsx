import { Box, Stack } from '@mantine/core';
import React from 'react'
import AppFooter from '~/components/app-footer';
import ProductsHeader from '~/components/products-header';

const ContactUs = () => {
    return (
        <div>AboutUs</div>
    )
}

export default ContactUs;