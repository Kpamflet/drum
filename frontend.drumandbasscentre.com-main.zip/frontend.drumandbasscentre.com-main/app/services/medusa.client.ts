import Medusa, { Config } from "@medusajs/medusa-js"

export default new Medusa({
    baseUrl: "https://backend-druman.fly.dev"
} as Config);