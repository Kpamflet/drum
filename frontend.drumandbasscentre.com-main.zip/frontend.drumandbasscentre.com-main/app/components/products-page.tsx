import { Paper } from '@mantine/core';
import { LoaderFunction } from '@vercel/remix';
import { useProducts } from 'medusa-react';
import React, { useEffect } from 'react'
import medusa from '~/services/medusa.server';

const ProductsPage = () => {

  return (
    <Paper>
    </Paper>
  )
}

export default ProductsPage;